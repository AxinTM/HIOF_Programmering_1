# Antall personer som spillser kake
person_1 = 5
person_2 = 9
person_3 = 2.5
person_4 = 21
person_5 = 0
total_person = 5
total_cookie = float((person_1 + person_2 + person_3 + person_4 + person_5))
print(f"Total antall kake: {total_cookie}\n")

# Gjennomsnittet
print("Gjennomsnittsforbruk av kake for 5 personer:")
print(int(total_cookie / total_person))
