# Mini Kalkulator

first_number = int(input("Tast inn et tall "))
second_number = int(input("Tast inn et annet tall "))
# Pluss
print(f"{first_number} + {second_number} = {first_number + second_number}")
# Minus
print(f"{first_number} - {second_number} = {first_number - second_number}")
# Gange
print(f"{first_number} * {second_number} = {first_number * second_number}")
# Dele
print(f"{first_number} / {second_number} = {first_number / second_number}")
# Modulo
print(f"{first_number} % {second_number} = {first_number % second_number}")
# Opphøyd
print(f"{first_number} ** {second_number} = {first_number ** second_number}")
# Dele med nedrunding
print(f"{first_number} // {second_number} = {first_number // second_number}")
