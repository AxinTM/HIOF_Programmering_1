# Variabler
a = 6
b = 3
c = 2

# oppgave a)
print("Oppgave a)")
print(f"{a} + {b} * {c} = {a + b * c}\n")
# oppgave b)
print("Oppgave b)")
print(f"({a} + {b}) * {c} = {(a + b) * c}\n")
# oppgave c)
print("Oppgave c)")
print(f"{a} / {b} / {c} = {a / b / c}\n")
# oppgave d)
print("Oppgave d)")
print(f"{a} / ({b} / {c}) = {a / (b / c)}\n")