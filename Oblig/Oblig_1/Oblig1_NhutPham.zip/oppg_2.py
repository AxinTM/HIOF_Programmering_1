# Oppgave 2 - Navn

first_name = "Nhut"
last_name = "Pham"
age = 35
print("Hei, jeg heter " + first_name + " " + last_name + " og er " + str(age) + " år gammel \n")

# Bruker f" slik at det er lettere å lese koden.
print(f"Hei, jeg heter {first_name} {last_name} og er {age} år gammel")
